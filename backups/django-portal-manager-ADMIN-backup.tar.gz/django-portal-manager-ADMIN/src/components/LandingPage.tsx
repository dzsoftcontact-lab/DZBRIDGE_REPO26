import React, { useState } from 'react';
import { UserRole, CustomKpiItem, UserProfile } from '../types';
import { useTranslation } from '../i18n/LanguageContext';
import {
  GraduationCap,
  Building2,
  ShieldCheck,
  ArrowRight,
  Globe2,
  Calendar,
  Award,
  Sparkles,
  Layers,
  CheckCircle2,
  ArrowUpRight,
  Compass,
  FileText,
  Users,
  Terminal,
  Activity,
  ChevronRight,
  Lock,
  X,
  Mail,
  MapPin,
} from 'lucide-react';

interface LandingPageProps {
  customKpis: CustomKpiItem[];
  scholars: UserProfile[];
  onSelectRole: (role: UserRole) => void;
  onNavigateTab: (tab: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  customKpis,
  scholars,
  onSelectRole,
  onNavigateTab,
}) => {
  const { lang, t } = useTranslation();
  const isAr = lang === 'ar';

  const [activePersonaTab, setActivePersonaTab] = useState<'scholar' | 'university' | 'admin'>('scholar');
  const [showRegisterModal, setShowRegisterModal] = useState<boolean>(false);
  const [regRole, setRegRole] = useState<'expert' | 'organization'>('expert');
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regAffiliation, setRegAffiliation] = useState('');
  const [regInterests, setRegInterests] = useState('');
  const [regSubmitted, setRegSubmitted] = useState<boolean>(false);

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName || !regEmail) return;
    setRegSubmitted(true);
    setTimeout(() => {
      setRegSubmitted(false);
      setShowRegisterModal(false);
      onSelectRole(regRole);
      onNavigateTab(regRole === 'expert' ? 'expert' : 'organization');
    }, 1200);
  };

  const featuredKpis = customKpis.filter((k) => k.displayOnLanding).slice(0, 4);

  return (
    <div className="min-h-screen bg-[#FDFCFB] text-slate-900 font-['Plus_Jakarta_Sans'] select-none">
      {/* 1. TOP BAR CONTRACT */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 px-6 py-3.5">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          {/* Zone 1: Single text element wordmark */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#3B0D2C] text-[#C89B3C] flex items-center justify-center font-black text-sm shadow-xs border border-[#C89B3C]/30">
              DZ
            </div>
            <a
              href="#hero"
              className="text-base font-black tracking-tight text-slate-900 flex items-center gap-1.5"
            >
              <span>DZ-Bridge</span>
              <span className="text-slate-300">·</span>
              <span className="text-xs font-semibold text-slate-500">Algerian Scholar Award</span>
            </a>
          </div>

          {/* Zone 2: 4-6 text links */}
          <nav className="hidden md:flex items-center gap-7 text-xs font-bold text-slate-600">
            <a href="#mission" className="hover:text-[#3B0D2C] transition-colors">
              Strategic Mission
            </a>
            <a href="#metrics" className="hover:text-[#3B0D2C] transition-colors">
              National Metrics
            </a>
            <a href="#personas" className="hover:text-[#3B0D2C] transition-colors">
              Role Portals
            </a>
            <a href="#diaspora-map" className="hover:text-[#3B0D2C] transition-colors">
              Global Bridge
            </a>
            <a href="#laureates" className="hover:text-[#3B0D2C] transition-colors">
              Laureates
            </a>
          </nav>

          {/* Zone 3: 1-2 primary actions */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => onNavigateTab('dashboard')}
              className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 transition"
            >
              <Activity className="w-3.5 h-3.5 text-[#C89B3C]" />
              <span>National Dashboard</span>
            </button>
            <button
              onClick={() => {
                onSelectRole('expert');
                onNavigateTab('expert');
              }}
              className="px-4 py-2 text-xs font-bold text-white bg-[#3B0D2C] hover:bg-[#4A1238] rounded-xl shadow-xs transition flex items-center gap-1.5"
            >
              <span>Enter Workspace</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </header>

      {/* 2. HERO SECTION */}
      <section id="hero" className="relative overflow-hidden bg-[#0F172A] text-white">
        {/* Background Image with Measured Gradient Scrim */}
        <div className="absolute inset-0 z-0 opacity-40 mix-blend-luminosity">
          <img
            src="/src/assets/images/hero_scholar_award_1791169441754.jpg"
            alt="Algerian Scholar Award Ceremony"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute inset-0 z-0 bg-gradient-to-t from-[#0F172A] via-[#0F172A]/75 to-transparent" />

        <div className="relative z-10 max-w-6xl mx-auto px-6 pt-20 pb-24 lg:pt-28 lg:pb-32 text-center">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#C89B3C]/20 border border-[#C89B3C]/40 text-[#C89B3C] text-xs font-bold mb-6 backdrop-blur-xs">
            <Award className="w-4 h-4" />
            <span>Ministry of Higher Education and Scientific Research (MESRS)</span>
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight text-white max-w-4xl mx-auto leading-tight font-['Plus_Jakarta_Sans']">
            Sovereign Digital Infrastructure for Algerian Scientific Excellence
          </h1>

          <p className="mt-6 text-base sm:text-lg text-slate-300 max-w-2xl mx-auto leading-relaxed font-normal">
            Mobilizing the world-class expertise of Algerian diaspora scholars to elevate national doctoral programs, co-design advanced laboratories, and seal formal bilateral research protocols.
          </p>

          {/* Persona Portals Quick Jump */}
          <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => {
                onSelectRole('expert');
                onNavigateTab('expert');
              }}
              className="bg-[#C89B3C] hover:bg-[#b5892f] text-slate-950 font-bold px-6 py-3.5 rounded-xl text-sm transition flex items-center gap-2 shadow-lg group"
            >
              <GraduationCap className="w-4 h-4 text-slate-950" />
              <span>Scholar Fellow Portal</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              onClick={() => {
                onSelectRole('organization');
                onNavigateTab('organization');
              }}
              className="bg-white/10 hover:bg-white/20 border border-white/20 text-white font-bold px-6 py-3.5 rounded-xl text-sm backdrop-blur-xs transition flex items-center gap-2 group"
            >
              <Building2 className="w-4 h-4 text-[#C89B3C]" />
              <span>University Host Hub</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              onClick={() => {
                onSelectRole('admin');
                onNavigateTab('dashboard');
              }}
              className="bg-white/10 hover:bg-white/20 border border-white/20 text-white font-bold px-6 py-3.5 rounded-xl text-sm backdrop-blur-xs transition flex items-center gap-2 group"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>MESRS Super Admin</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          <div className="mt-10 flex items-center justify-center gap-6 text-xs text-slate-400 font-medium">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-[#C89B3C]" />
              <span>Zero Pill Discipline</span>
            </span>
            <span aria-hidden="true">·</span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>PostgreSQL 16 Engine</span>
            </span>
            <span aria-hidden="true">·</span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-blue-400" />
              <span>Real-Time Bilateral Matchmaking</span>
            </span>
          </div>
        </div>
      </section>

      {/* 3. NATIONAL IMPACT METRICS (Configured via KPI Builder) */}
      <section id="metrics" className="py-14 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-[#8C6514] block mb-1">
                Verified Platform Performance
              </span>
              <h2 className="text-2xl font-black text-slate-900 tracking-tight">
                National Knowledge Transfer Indicators
              </h2>
            </div>
            <button
              onClick={() => {
                onSelectRole('admin');
                onNavigateTab('kpi-studio');
              }}
              className="text-xs font-bold text-[#3B0D2C] hover:text-[#C89B3C] flex items-center gap-1 self-start md:self-end"
            >
              <span>Manage Custom KPIs in Admin Console</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {featuredKpis.map((kpi) => (
              <div
                key={kpi.id}
                className="bg-slate-50/70 border border-slate-200 rounded-2xl p-5 hover:border-[#C89B3C] transition-colors"
              >
                <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2">
                  {kpi.category}
                </div>
                <div className="text-3xl font-black text-slate-900 font-mono tracking-tight tabular-nums">
                  {kpi.currentValue}
                  {kpi.unit && <span className="text-xs font-bold text-slate-500 ml-1">{kpi.unit}</span>}
                </div>
                <div className="text-xs font-semibold text-slate-700 mt-1 line-clamp-1">
                  {kpi.name}
                </div>
                <div className="mt-3 pt-3 border-t border-slate-200/70 flex items-center justify-between text-[11px]">
                  <span className="text-slate-400">Target: {kpi.targetValue}</span>
                  <span className="font-mono font-bold text-emerald-700">
                    {kpi.progressPercentage}% Complete
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. PERSONA CAPABILITIES BENTO (Features & Role Portals) */}
      <section id="personas" className="py-20 bg-slate-50/60 border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <span className="text-xs font-bold uppercase tracking-wider text-[#8C6514] block mb-1">
              Role-Specific Workspaces
            </span>
            <h2 className="text-3xl font-black text-slate-900 tracking-tight">
              A Tailored Architecture for Every Stakeholder
            </h2>
            <p className="text-sm text-slate-600 mt-2">
              Each portal provides dedicated tools, permissions, and automated workflows designed to accelerate bilateral academic cooperation.
            </p>
          </div>

          {/* Interactive Persona Selector Tabs */}
          <div className="flex justify-center mb-10">
            <div className="inline-flex items-center gap-1.5 p-1.5 bg-slate-200/80 rounded-2xl border border-slate-300">
              <button
                onClick={() => setActivePersonaTab('scholar')}
                className={`px-5 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
                  activePersonaTab === 'scholar'
                    ? 'bg-white text-[#3B0D2C] shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <GraduationCap className="w-4 h-4 text-[#C89B3C]" />
                <span>Diaspora Scholars</span>
              </button>
              <button
                onClick={() => setActivePersonaTab('university')}
                className={`px-5 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
                  activePersonaTab === 'university'
                    ? 'bg-white text-[#3B0D2C] shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Building2 className="w-4 h-4 text-[#3B0D2C]" />
                <span>Universities & Labs</span>
              </button>
              <button
                onClick={() => setActivePersonaTab('admin')}
                className={`px-5 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
                  activePersonaTab === 'admin'
                    ? 'bg-white text-[#3B0D2C] shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>MESRS Super Admin</span>
              </button>
            </div>
          </div>

          {/* Persona Card Detail */}
          <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm">
            {activePersonaTab === 'scholar' && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                <div className="lg:col-span-7 space-y-4">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-50 text-[#8C6514] text-xs font-bold border border-amber-200">
                    <Award className="w-3.5 h-3.5" />
                    <span>For Laureates & Fellow Researchers Worldwide</span>
                  </div>
                  <h3 className="text-2xl font-black text-slate-900 tracking-tight">
                    Diaspora Scholar Workspace
                  </h3>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    Designed for Algerian scientists, engineers, and scholars established abroad. Declare your travel and visit windows to Algeria, receive deterministic challenge matches from national faculties, and mentor the next generation of doctoral candidates.
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                      <div className="font-bold text-xs text-slate-900 flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-[#C89B3C]" />
                        <span>Visit Window Calendar</span>
                      </div>
                      <p className="text-xs text-slate-500 mt-1">
                        Post physical presence in Algiers, Oran, Constantine with covered flights & lodging.
                      </p>
                    </div>
                    <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                      <div className="font-bold text-xs text-slate-900 flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-[#C89B3C]" />
                        <span>Algorithmic Compatibility</span>
                      </div>
                      <p className="text-xs text-slate-500 mt-1">
                        Transparent 4-factor scoring (45% skills + 25% timeline + 15% location + 15% diaspora).
                      </p>
                    </div>
                    <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                      <div className="font-bold text-xs text-slate-900 flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-[#C89B3C]" />
                        <span>Bilateral Agreements</span>
                      </div>
                      <p className="text-xs text-slate-500 mt-1">
                        One-click acceptance locks in direct faculty contact and formal cooperation protocol.
                      </p>
                    </div>
                    <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                      <div className="font-bold text-xs text-slate-900 flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-[#C89B3C]" />
                        <span>Verified Fellow Credential</span>
                      </div>
                      <p className="text-xs text-slate-500 mt-1">
                        Official national accreditation recognized by Algerian higher education authorities.
                      </p>
                    </div>
                  </div>

                  <div className="pt-4">
                    <button
                      onClick={() => {
                        onSelectRole('expert');
                        onNavigateTab('expert');
                      }}
                      className="bg-[#3B0D2C] hover:bg-[#4A1238] text-white font-bold px-6 py-3 rounded-xl text-xs transition flex items-center gap-2 shadow-xs"
                    >
                      <span>Open Scholar Workspace</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="lg:col-span-5 bg-gradient-to-br from-[#3B0D2C]/5 via-amber-50/30 to-slate-100 p-6 rounded-2xl border border-slate-200">
                  <div className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">
                    Active Laureate Profile Sample
                  </div>
                  <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-3 shadow-2xs">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-xl bg-[#3B0D2C] text-[#C89B3C] font-black flex items-center justify-center text-sm">
                        DK
                      </div>
                      <div>
                        <div className="font-bold text-sm text-slate-900">Dr. Karim Mansouri</div>
                        <div className="text-xs text-slate-500">Oxford Robotics Institute · UK Diaspora</div>
                      </div>
                    </div>
                    <div className="text-xs text-slate-600 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                      Expertise: Autonomous Systems, Aerial Robotics, Deep SLAM
                    </div>
                    <div className="flex items-center justify-between text-xs text-emerald-700 font-bold bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200">
                      <span>Algeria Visit: Nov 15 – Nov 28</span>
                      <span>Algiers / USTHB</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activePersonaTab === 'university' && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                <div className="lg:col-span-7 space-y-4">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-800 text-xs font-bold border border-blue-200">
                    <Building2 className="w-3.5 h-3.5" />
                    <span>For Rectors, Faculty Deans & Laboratory Directors</span>
                  </div>
                  <h3 className="text-2xl font-black text-slate-900 tracking-tight">
                    University & Research Institute Portal
                  </h3>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    Post strategic doctoral challenges, recruit renowned Algerian experts abroad, and streamline logistics support packages through an audited 8-stage state machine.
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                      <div className="font-bold text-xs text-slate-900 flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-blue-600" />
                        <span>Project Proposal Builder</span>
                      </div>
                      <p className="text-xs text-slate-500 mt-1">
                        Formulate initiatives with skill criteria, location, and structured logistics tags.
                      </p>
                    </div>
                    <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                      <div className="font-bold text-xs text-slate-900 flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-blue-600" />
                        <span>Instant Diaspora Matchmaking</span>
                      </div>
                      <p className="text-xs text-slate-500 mt-1">
                        Immediate algorithmic alignment against verified Algerian scholar candidates.
                      </p>
                    </div>
                    <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                      <div className="font-bold text-xs text-slate-900 flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-blue-600" />
                        <span>State Machine Governance</span>
                      </div>
                      <p className="text-xs text-slate-500 mt-1">
                        Finite State Machine tracks transitions from draft to confirmed institutional protocol.
                      </p>
                    </div>
                    <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                      <div className="font-bold text-xs text-slate-900 flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-blue-600" />
                        <span>Formal Institutional Protocols</span>
                      </div>
                      <p className="text-xs text-slate-500 mt-1">
                        Download ratified bilateral agreement documents with cryptographic audit seals.
                      </p>
                    </div>
                  </div>

                  <div className="pt-4">
                    <button
                      onClick={() => {
                        onSelectRole('organization');
                        onNavigateTab('organization');
                      }}
                      className="bg-[#3B0D2C] hover:bg-[#4A1238] text-white font-bold px-6 py-3 rounded-xl text-xs transition flex items-center gap-2 shadow-xs"
                    >
                      <span>Open University Portal</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="lg:col-span-5 bg-gradient-to-br from-blue-50/40 via-white to-slate-100 p-6 rounded-2xl border border-slate-200">
                  <div className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">
                    Active Faculty Challenge Sample
                  </div>
                  <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-3 shadow-2xs">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-blue-700 bg-blue-50 px-2.5 py-0.5 rounded-full border border-blue-200">
                        USTHB · Faculty of Electronics
                      </span>
                      <span className="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-full">
                        State: Matched
                      </span>
                    </div>
                    <div className="font-bold text-sm text-slate-900">
                      Next-Gen 6G Terahertz Antenna Design Lab
                    </div>
                    <div className="text-xs text-slate-500 leading-relaxed">
                      Co-supervision of 3 doctoral theses, curriculum upgrade, and electromagnetic laboratory commissioning.
                    </div>
                    <div className="text-[11px] text-slate-600 flex items-center justify-between border-t border-slate-100 pt-2">
                      <span>Logistics: Flights + Villa</span>
                      <span className="font-mono font-bold text-[#3B0D2C]">Match Score: 94.2%</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activePersonaTab === 'admin' && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                <div className="lg:col-span-7 space-y-4">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 text-xs font-bold border border-emerald-200">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>For MESRS Directorate & Program Regulators</span>
                  </div>
                  <h3 className="text-2xl font-black text-slate-900 tracking-tight">
                    MESRS Super Admin & Governance Console
                  </h3>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    Sovereign platform supervision with dynamic Custom KPI Management, automated RFC-7807 API gateway integration, and PostgreSQL database management with DDL and multi-sheet Excel export.
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                      <div className="font-bold text-xs text-slate-900 flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>Custom KPI Management</span>
                      </div>
                      <p className="text-xs text-slate-500 mt-1">
                        Visually construct and publish platform metrics with targets and formula bindings.
                      </p>
                    </div>
                    <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                      <div className="font-bold text-xs text-slate-900 flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>PostgreSQL Schema Studio</span>
                      </div>
                      <p className="text-xs text-slate-500 mt-1">
                        Add tables, configure foreign keys, toggle ERD fixed physics, export SQL/XLSX.
                      </p>
                    </div>
                    <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                      <div className="font-bold text-xs text-slate-900 flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>API Management Sandbox</span>
                      </div>
                      <p className="text-xs text-slate-500 mt-1">
                        14+ endpoints tested across in-browser DB, Django REST Framework, and NestJS.
                      </p>
                    </div>
                    <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                      <div className="font-bold text-xs text-slate-900 flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>Cryptographic Audit Log</span>
                      </div>
                      <p className="text-xs text-slate-500 mt-1">
                        Immutable ledger tracking every transaction, user access, and protocol ratification.
                      </p>
                    </div>
                  </div>

                  <div className="pt-4 flex items-center gap-3">
                    <button
                      onClick={() => {
                        onSelectRole('admin');
                        onNavigateTab('dashboard');
                      }}
                      className="bg-[#3B0D2C] hover:bg-[#4A1238] text-white font-bold px-6 py-3 rounded-xl text-xs transition flex items-center gap-2 shadow-xs"
                    >
                      <span>Open Admin Console</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => {
                        onSelectRole('admin');
                        onNavigateTab('kpi-studio');
                      }}
                      className="bg-white border border-slate-300 hover:bg-slate-50 text-slate-800 font-bold px-5 py-3 rounded-xl text-xs transition"
                    >
                      <span>Custom KPI Studio</span>
                    </button>
                  </div>
                </div>

                <div className="lg:col-span-5 bg-gradient-to-br from-emerald-50/40 via-white to-slate-100 p-6 rounded-2xl border border-slate-200">
                  <div className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">
                    Sovereign Governance Telemetry
                  </div>
                  <div className="bg-slate-900 text-emerald-400 p-4 rounded-xl font-mono text-xs space-y-2 border border-slate-800">
                    <div className="flex items-center justify-between text-slate-400 text-[11px] pb-1 border-b border-slate-800">
                      <span>STATUS: ALL NODES OPERATIONAL</span>
                      <span className="text-[#C89B3C]">MESRS-DZ-SOVEREIGN</span>
                    </div>
                    <div>PostgreSQL 16: Active / Schema Synced</div>
                    <div>Foreign Keys: Cascade Protected</div>
                    <div>Audit Log Hash: SHA-256 Validated</div>
                    <div className="text-amber-300 text-[11px] pt-1">
                      Active Laureates Tracked: 276
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* 5. GLOBAL KNOWLEDGE BRIDGE MAP */}
      <section id="diaspora-map" className="py-20 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <span className="text-xs font-bold uppercase tracking-wider text-[#8C6514] block mb-1">
              Worldwide Algerian Scientific Network
            </span>
            <h2 className="text-3xl font-black text-slate-900 tracking-tight">
              Bridging Global Research Hubs to National Universities
            </h2>
            <p className="text-sm text-slate-600 mt-2">
              Bilateral knowledge conduits connecting top international research institutions with faculties across Algeria's 58 wilayas.
            </p>
          </div>

          <div className="bg-slate-900 text-white rounded-3xl p-8 relative overflow-hidden border border-slate-800 shadow-xl">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div className="space-y-4">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#C89B3C]/20 text-[#C89B3C] text-xs font-bold border border-[#C89B3C]/40">
                  <Globe2 className="w-3.5 h-3.5" />
                  <span>Strategic Diaspora Corridors</span>
                </div>
                <h3 className="text-2xl font-bold tracking-tight text-white font-['Plus_Jakarta_Sans']">
                  Direct Bilateral Transfer Conduits
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Scholars stationed at MIT, Cambridge, CNRS Paris, EPFL Lausanne, Tokyo University, and KAUST collaborate through formalized visiting professorships and hybrid doctoral guidance.
                </p>

                <div className="space-y-2 pt-2">
                  <div className="flex items-center justify-between text-xs bg-slate-800/80 p-2.5 rounded-xl border border-slate-700">
                    <span className="text-slate-300 font-semibold">Silicon Valley / MIT ──► USTHB Algiers</span>
                    <span className="text-[#C89B3C] font-mono font-bold">AI & Microelectronics</span>
                  </div>
                  <div className="flex items-center justify-between text-xs bg-slate-800/80 p-2.5 rounded-xl border border-slate-700">
                    <span className="text-slate-300 font-semibold">CNRS Paris / Sorbonne ──► Univ. Oran 1</span>
                    <span className="text-emerald-400 font-mono font-bold">Biotechnology & Oncology</span>
                  </div>
                  <div className="flex items-center justify-between text-xs bg-slate-800/80 p-2.5 rounded-xl border border-slate-700">
                    <span className="text-slate-300 font-semibold">EPFL Lausanne / Oxford ──► Univ. Constantine 1</span>
                    <span className="text-blue-400 font-mono font-bold">Renewable Energy & H2</span>
                  </div>
                </div>
              </div>

              {/* Graphic Representation */}
              <div className="bg-slate-950 p-6 rounded-2xl border border-slate-800 text-center space-y-4">
                <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                  Active Knowledge Flow Distribution
                </div>
                <div className="grid grid-cols-2 gap-3 text-left font-mono text-xs">
                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                    <div className="text-slate-400 text-[10px]">EUROPE REGION</div>
                    <div className="text-lg font-bold text-white tabular-nums">54.2%</div>
                    <div className="text-[10px] text-slate-500">149 Active Fellows</div>
                  </div>
                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                    <div className="text-slate-400 text-[10px]">NORTH AMERICA</div>
                    <div className="text-lg font-bold text-white tabular-nums">28.6%</div>
                    <div className="text-[10px] text-slate-500">79 Active Fellows</div>
                  </div>
                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                    <div className="text-slate-400 text-[10px]">ASIA PACIFIC</div>
                    <div className="text-lg font-bold text-white tabular-nums">11.4%</div>
                    <div className="text-[10px] text-slate-500">31 Active Fellows</div>
                  </div>
                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                    <div className="text-slate-400 text-[10px]">GULF & MENA</div>
                    <div className="text-lg font-bold text-white tabular-nums">5.8%</div>
                    <div className="text-[10px] text-slate-500">16 Active Fellows</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6. FEATURED LAUREATES SPOTLIGHT */}
      <section id="laureates" className="py-20 bg-slate-50/60 border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-[#8C6514] block mb-1">
                Distinguished Algerian Scholar Award Fellows
              </span>
              <h2 className="text-2xl font-black text-slate-900 tracking-tight">
                Featured Laureates & Research Mentors
              </h2>
            </div>
            <button
              onClick={() => setShowRegisterModal(true)}
              className="text-xs font-bold text-[#3B0D2C] hover:text-[#C89B3C] flex items-center gap-1"
            >
              <span>Join as an Academic Fellow</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {scholars.slice(0, 3).map((scholar) => (
              <div
                key={scholar.id}
                className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-[#3B0D2C] text-[#C89B3C] font-black flex items-center justify-center text-sm">
                      {scholar.fullName.split(' ').map((n) => n[0]).join('')}
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-slate-900">{scholar.fullName}</h4>
                      <div className="text-xs text-slate-500">
                        {scholar.affiliation || scholar.organizationName || 'University Faculty'}
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">
                    {scholar.bio || 'Distinguished researcher committed to doctoral co-supervision and laboratory modernization in Algeria.'}
                  </p>

                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {scholar.expertiseTags.slice(0, 3).map((tag, idx) => (
                      <span
                        key={idx}
                        className="text-[11px] font-semibold text-slate-700 bg-slate-100 px-2 py-0.5 rounded-lg"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-slate-500 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    <span>{scholar.country || 'International'}</span>
                  </span>
                  <button
                    onClick={() => {
                      onSelectRole('expert');
                      onNavigateTab('expert');
                    }}
                    className="text-[#3B0D2C] hover:text-[#C89B3C] font-bold flex items-center gap-1"
                  >
                    <span>View Profile</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 7. REGISTRATION MODAL */}
      {showRegisterModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-slate-100">
              <h4 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#C89B3C]" />
                Join the Algerian Knowledge Transfer Network
              </h4>
              <button onClick={() => setShowRegisterModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            {regSubmitted ? (
              <div className="py-8 text-center space-y-2 animate-in fade-in">
                <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto" />
                <h5 className="font-bold text-base text-slate-900">Registration Processed</h5>
                <p className="text-xs text-slate-500">Redirecting to your dedicated workspace portal...</p>
              </div>
            ) : (
              <form onSubmit={handleRegisterSubmit} className="space-y-3.5 text-xs">
                <div>
                  <label className="text-slate-700 font-bold block mb-1">Select Your Profile Role</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setRegRole('expert')}
                      className={`p-2.5 rounded-xl border font-bold text-xs flex items-center justify-center gap-1.5 transition ${
                        regRole === 'expert'
                          ? 'bg-[#3B0D2C] text-white border-[#3B0D2C]'
                          : 'bg-white border-slate-300 text-slate-700'
                      }`}
                    >
                      <GraduationCap className="w-3.5 h-3.5 text-[#C89B3C]" />
                      <span>Diaspora Scholar</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setRegRole('organization')}
                      className={`p-2.5 rounded-xl border font-bold text-xs flex items-center justify-center gap-1.5 transition ${
                        regRole === 'organization'
                          ? 'bg-[#3B0D2C] text-white border-[#3B0D2C]'
                          : 'bg-white border-slate-300 text-slate-700'
                      }`}
                    >
                      <Building2 className="w-3.5 h-3.5 text-[#C89B3C]" />
                      <span>University Faculty</span>
                    </button>
                  </div>
                </div>

                <div>
                  <label className="text-slate-700 font-bold block mb-1">Full Name & Academic Title</label>
                  <input
                    type="text"
                    required
                    placeholder="Prof. / Dr. Full Name"
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#3B0D2C]/20"
                  />
                </div>

                <div>
                  <label className="text-slate-700 font-bold block mb-1">Academic Email</label>
                  <input
                    type="email"
                    required
                    placeholder="scholar@university.edu"
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#3B0D2C]/20"
                  />
                </div>

                <div>
                  <label className="text-slate-700 font-bold block mb-1">Current Academic Affiliation</label>
                  <input
                    type="text"
                    placeholder="e.g. Oxford, Stanford, Sorbonne, USTHB"
                    value={regAffiliation}
                    onChange={(e) => setRegAffiliation(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#3B0D2C]/20"
                  />
                </div>

                <div>
                  <label className="text-slate-700 font-bold block mb-1">Primary Research Fields</label>
                  <input
                    type="text"
                    placeholder="e.g. Artificial Intelligence, Renewable Hydrogen, Oncology"
                    value={regInterests}
                    onChange={(e) => setRegInterests(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#3B0D2C]/20"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setShowRegisterModal(false)}
                    className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="bg-[#3B0D2C] hover:bg-[#4A1238] text-white font-bold px-4 py-2 rounded-xl transition shadow"
                  >
                    Complete Onboarding
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* 8. SOVEREIGN INSTITUTIONAL FOOTER */}
      <footer className="bg-slate-950 text-white py-12 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 pb-8 border-b border-slate-800 text-xs">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-[#3B0D2C] text-[#C89B3C] font-black flex items-center justify-center text-xs border border-[#C89B3C]/30">
                DZ
              </div>
              <div>
                <span className="font-bold text-white block">DZ-Bridge Sovereign System</span>
                <span className="text-slate-400">Algerian Scholar Award · MESRS Directorate</span>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-6 text-slate-400">
              <button
                onClick={() => {
                  onSelectRole('expert');
                  onNavigateTab('expert');
                }}
                className="hover:text-white transition-colors"
              >
                Scholar Workspace
              </button>
              <button
                onClick={() => {
                  onSelectRole('organization');
                  onNavigateTab('organization');
                }}
                className="hover:text-white transition-colors"
              >
                University Portal
              </button>
              <button
                onClick={() => {
                  onSelectRole('admin');
                  onNavigateTab('dashboard');
                }}
                className="hover:text-white transition-colors"
              >
                Super Admin Console
              </button>
              <button
                onClick={() => onNavigateTab('database')}
                className="hover:text-white transition-colors"
              >
                PostgreSQL Studio
              </button>
            </div>
          </div>

          <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-slate-500">
            <div>
              © 2026 People's Democratic Republic of Algeria · Ministry of Higher Education & Scientific Research.
            </div>
            <div className="flex items-center gap-4">
              <span>Encrypted SHA-256 Ledger</span>
              <span>·</span>
              <span>PostgreSQL 16 Engine</span>
              <span>·</span>
              <span>Zero-Pill Typography</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
